from flask import Flask, jsonify, render_template, request
import os
import config
from sheets_connector_public import SheetsConnector
import pandas as pd
from datetime import datetime, timedelta

app = Flask(__name__)

# Initialize the Google Sheets connector
sheets_connector = SheetsConnector(config.SPREADSHEET_ID)
sheets_connector.column_mapping = config.COLUMN_MAPPING
sheets_connector.features = config.FEATURES


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/latest-data")
def get_latest_data():
    """
    Returns the latest data for the UI to display.

    If `fresh=1` is passed, force a pull from Google Sheets first to avoid stale cache.
    """
    try:
        fresh = request.args.get("fresh") == "1"
        if fresh:
            # Pull latest into memory/cache first
            sheets_connector.update_data()
        latest_data = sheets_connector.get_latest_data()
        return jsonify(latest_data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/history")
def get_history_data():
    """
    Returns time-filtered series for the selected type (prediction, pH, TDS, etc.)
    Query params:
      - hours=<int>  OR  start=<YYYY-MM-DD>&end=<YYYY-MM-DD>
      - type=<column name>  (defaults to 'prediction')
      - fresh=1 to force re-pull from Google Sheets before reading the DataFrame
    Response:
      { "timestamps": [...], "values": [...] }
    """
    try:
        fresh = request.args.get("fresh") == "1"
        if fresh:
            # Pull latest before loading DataFrame to avoid stale data
            sheets_connector.update_data()

        # Load DataFrame; allow a hard reload of the cached copy when fresh=True
        df = sheets_connector.load_full_dataframe(force_reload=fresh)

        # Normalize and sort timestamps
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
        df.dropna(subset=["timestamp"], inplace=True)
        df.sort_values(by="timestamp", inplace=True)

        hours = request.args.get("hours")
        start = request.args.get("start")
        end = request.args.get("end")
        selected_type = request.args.get("type", "prediction")

        if selected_type not in df.columns:
            return jsonify({"error": f"Missing '{selected_type}' column in data"}), 400

        if not hours and not (start and end):
            return jsonify({"error": "Missing query parameters"}), 400

        # Apply time filter
        if hours:
            try:
                hours = int(hours)
            except ValueError:
                return jsonify({"error": "Invalid hours parameter"}), 400
            cutoff = datetime.now() - timedelta(hours=hours)
            df = df[df["timestamp"] >= cutoff]
        else:
            try:
                start_dt = pd.to_datetime(start)
                end_dt = pd.to_datetime(end) + pd.Timedelta(days=1)  # inclusive of end date
            except Exception:
                return jsonify({"error": "Invalid start/end date"}), 400
            df = df[(df["timestamp"] >= start_dt) & (df["timestamp"] < end_dt)]

        if df.empty:
            return jsonify({"timestamps": [], "values": []})

        timestamps = df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S").tolist()
        # Ensure numeric series for the selected column
        values = pd.to_numeric(df[selected_type], errors="coerce").fillna(0).astype(float).tolist()

        return jsonify({"timestamps": timestamps, "values": values})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/manual-update")
def manual_update():
    """
    Manually trigger an update from Google Sheets.
    The frontend calls this first, then separately calls /api/latest-data and /api/history with fresh flags.
    """
    try:
        sheets_connector.update_data()
        return jsonify({"status": "ok"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Ensure templates folder exists
os.makedirs("templates", exist_ok=True)

# Create a basic index.html if not already provided
if not os.path.exists("templates/index.html"):
    with open("templates/index.html", "w") as f:
        f.write("""
        <!DOCTYPE html>
        <html lang="en">
        <head><meta charset="UTF-8"><title>EcoWatch</title></head>
        <body><h1>EcoWatch Dashboard is running.</h1></body>
        </html>
        """)


@app.after_request
def add_headers(resp):
    # Make sure browsers/proxies do not cache API responses
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    # Tell Ngrok to skip its first-visit browser warning page
    resp.headers["ngrok-skip-browser-warning"] = "true"
    return resp


if __name__ == "__main__":
    app.run(debug=config.DEBUG, host=config.HOST, port=config.PORT)
