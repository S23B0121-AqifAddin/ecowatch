import requests
import time
from io import StringIO
import pandas as pd
from datetime import datetime, timedelta


class SheetsConnector:
    def __init__(self, spreadsheet_id: str):
        self.spreadsheet_id = spreadsheet_id

        if "docs.google.com/spreadsheets/d/e/" in spreadsheet_id:
            parts = spreadsheet_id.split("/")
            export_id = next((part for part in parts if part.startswith("2PACX-")), "")
            # Base CSV URL (we'll append a cache-buster on each fetch)
            self.sheets_url = f"https://docs.google.com/spreadsheets/d/e/{export_id}/pub?output=csv"
            self.is_csv_format = True
        else:
            # Legacy JSON (unused in this project, but kept for compatibility)
            self.sheets_url = f"https://spreadsheets.google.com/feeds/list/{spreadsheet_id}/1/public/values?alt=json"
            self.is_csv_format = False

        # Columns we expect from your sheet
        self.features = ["pH", "TDS", "Turbidity", "Temperature"]
        self.column_mapping = {
            "ph": "pH",
            "tds": "TDS",
            "turbidity": "Turbidity",
            "temperature": "Temperature",
            "predictedwqi": "Predicted WQI",
        }

        # In-memory cache
        self.last_data = None             # list of latest features [pH, TDS, ...]
        self.last_prediction = None       # float Predicted WQI
        self.last_update_time = None      # yyyy-mm-dd HH:MM:SS
        self.cached_df: pd.DataFrame | None = None  # full-frame cache

        # No background scheduler here — fully manual pull

    # -------------------------
    # Low-level network helpers
    # -------------------------
    def _csv_url_with_buster(self) -> str:
        """Append a cache-busting query param to avoid CDN-stale CSV."""
        ts = int(time.time() * 1000)
        sep = "&" if "?" in self.sheets_url else "?"
        return f"{self.sheets_url}{sep}_t={ts}"

    def _fetch_csv_text(self, force_network: bool = True) -> str:
        """
        Fetch CSV text. When force_network=True, we add a cache-buster and
        send 'no-cache' headers to pierce intermediary caches.
        """
        url = self._csv_url_with_buster() if force_network else self.sheets_url
        headers = {
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        }
        resp = requests.get(url, headers=headers, timeout=10)
        resp.raise_for_status()
        return resp.text

    def _parse_csv_to_df(self, csv_text: str) -> pd.DataFrame:
        df = pd.read_csv(StringIO(csv_text))
        df.columns = [col.strip() for col in df.columns]
        return df

    # -------------------------
    # Public interface
    # -------------------------
    def get_latest_row(self, force_network: bool = True):
        """
        Pull the full CSV, cache it, and extract the latest row as 'summary'
        values for the dashboard top card.
        """
        try:
            csv_text = self._fetch_csv_text(force_network=force_network)
            df = self._parse_csv_to_df(csv_text)
            self.cached_df = df.copy()

            if df.empty:
                raise Exception("CSV returned no rows")

            latest_entry = df.iloc[-1].to_dict()

            # features array in the order defined by self.features
            features_values = []
            for feature in self.features:
                raw = latest_entry.get(feature, "")
                try:
                    value = float(str(raw).strip())
                except Exception:
                    value = 0.0
                features_values.append(value)

            # Predicted WQI
            try:
                predicted_wqi = float(str(latest_entry.get("Predicted WQI", "0")).strip())
            except Exception:
                predicted_wqi = 0.0

            self.last_data = features_values
            self.last_prediction = predicted_wqi
            self.last_update_time = time.strftime("%Y-%m-%d %H:%M:%S")

            return features_values

        except Exception as e:
            print(f"[SheetsConnector] Error get_latest_row: {e}")
            return None

    def update_data(self, force_network: bool = True):
        """
        Manual update hook. Always prefer force_network=True to dodge caches.
        """
        print("[SheetsConnector] Updating data from Google Sheets...")
        self.get_latest_row(force_network=force_network)

    def get_latest_data(self, force_reload: bool = False):
        """
        Return the latest summary data for the dashboard header.
        If force_reload=True, re-pull from the sheet first.
        """
        if force_reload or self.last_data is None:
            self.get_latest_row(force_network=True)

        return {
            "features": self.last_data,
            "prediction": self.last_prediction,
            "update_time": self.last_update_time,
            "feature_names": self.features,
        }

    def load_full_dataframe(self, force_reload: bool = False) -> pd.DataFrame:
        """
        Return the full DataFrame of the sheet. If force_reload=True, fetch
        from the network with a cache-buster first.
        """
        try:
            if not force_reload and self.cached_df is not None:
                df = self.cached_df.copy()
            else:
                csv_text = self._fetch_csv_text(force_network=True)
                df = self._parse_csv_to_df(csv_text)
                self.cached_df = df.copy()

            # Required columns
            if "timestamp" not in df.columns or "Predicted WQI" not in df.columns:
                raise Exception("Required columns 'timestamp' and 'Predicted WQI' not found in sheet")

            # Normalize
            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
            df["prediction"] = pd.to_numeric(df["Predicted WQI"], errors="coerce")

            # Optional numeric parsing
            for col in ["pH", "TDS", "Turbidity", "Temperature"]:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors="coerce")

            df.dropna(subset=["timestamp", "prediction"], inplace=True)
            df.sort_values(by="timestamp", inplace=True)

            return df

        except Exception as e:
            print(f"[SheetsConnector] Error load_full_dataframe: {e}")
            return pd.DataFrame(columns=["timestamp", "prediction"])

    def get_history_data(
        self,
        hours: int | None = None,
        start: str | None = None,
        end: str | None = None,
        type_key: str = "prediction",
        force_reload: bool = False,
    ):
        """
        Returns history for given type (prediction, pH, TDS, etc.)
        """
        try:
            df = self.load_full_dataframe(force_reload=force_reload)
            if df.empty:
                return {"timestamps": [], "values": []}

            if type_key not in df.columns:
                raise Exception(f"Column {type_key} not found in sheet")

            if hours:
                cutoff = datetime.now() - timedelta(hours=int(hours))
                df = df[df["timestamp"] >= cutoff]
            elif start and end:
                start_dt = datetime.strptime(start, "%Y-%m-%d")
                end_dt = datetime.strptime(end, "%Y-%m-%d") + timedelta(days=1)
                df = df[(df["timestamp"] >= start_dt) & (df["timestamp"] < end_dt)]

            return {
                "timestamps": df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S").tolist(),
                "values": pd.to_numeric(df[type_key], errors="coerce").round(2).fillna(0).tolist(),
            }

        except Exception as e:
            print(f"[SheetsConnector] Error get_history_data: {e}")
            return {"timestamps": [], "values": []}


# For manual testing
if __name__ == "__main__":
    connector = SheetsConnector(
        "https://docs.google.com/spreadsheets/d/e/2PACX-1vQxvp6iMsxUCzFJRt4V7QQR2mkhEvIb2vAIDKG3GlC_a5PrNrU2IJ2gP2DHqOlz_095HlHDXpa1kAsK/pub?output=csv"
    )
    connector.update_data(force_network=True)
    print("Latest:", connector.get_latest_data())
    hist = connector.get_history_data(hours=1, type_key="prediction", force_reload=True)
    print("Hist sample:", {k: v[:3] for k, v in hist.items()})
