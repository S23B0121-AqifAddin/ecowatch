@echo off
echo ========================================================
echo Water Quality Index Predictor System
echo Using Google Sheets Public JSON Endpoint
echo ========================================================
echo.

echo Step 1: Checking configuration...
python -c "import sys, os; sys.path.insert(0, os.getcwd()); import config; print(config.SPREADSHEET_ID)"
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Configuration check failed. Please make sure config.py is properly set up.
    pause
    exit /b
)
echo.

echo Step 2: Starting Flask Application with UI
start /B python app.py
echo.

echo Step 3: Waiting for Flask to initialize (5 seconds)
timeout /t 5 > nul
echo.

echo Step 4: Starting ngrok tunnel
start /B ngrok http 5000
echo.

echo ========================================================
echo System started successfully! 
echo.
echo LOCAL ACCESS:
echo - Web UI: http://localhost:5000
echo.
echo REMOTE ACCESS:
echo - Check the ngrok window for your public URL
echo.
echo The system will automatically update data every %UPDATE_INTERVAL% minutes
echo ========================================================
echo.
echo Press any key to stop the system
pause > nul