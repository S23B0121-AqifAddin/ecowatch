import requests
import time
import schedule
import threading
import csv
from io import StringIO
import pandas as pd  # Make sure pandas is installed: pip install pandas
from datetime import datetime, timedelta

class SheetsConnector:
    def __init__(self, spreadsheet_id):
        self.spreadsheet_id = spreadsheet_id

        if "docs.google.com/spreadsheets/d/e/" in spreadsheet_id:
            parts = spreadsheet_id.split("/")
            export_id = next((part for part in parts if part.startswith("2PACX-")), "")
            self.sheets_url = f"https://docs.google.com/spreadsheets/d/e/{export_id}/pub?output=csv"
            self.is_csv_format = True
        else:
            self.sheets_url = f"https://spreadsheets.google.com/feeds/list/{spreadsheet_id}/1/public/values?alt=json"
            self.is_csv_format = False

        self.features = ["pH", "TDS", "Turbidity", "Temperature"]
        self.column_mapping = {
            "ph": "pH",
            "tds": "TDS",
            "turbidity": "Turbidity",
            "temperature": "Temperature",
            "predictedwqi": "Predicted WQI"
        }

        self.last_data = None
        self.last_prediction = None
        self.last_update_time = None
        self.cached_df = None  # full dataframe cache

        self.start_scheduler()

    def get_latest_row(self):
        try:
            response = requests.get(self.sheets_url)
            if response.status_code != 200:
                print(f"Error fetching data: HTTP {response.status_code}")
                return None

            csv_data = response.content.decode('utf-8')
            reader = csv.DictReader(StringIO(csv_data))
            rows = list(reader)
            if not rows:
                print("No data found in CSV")
                return None

            latest_entry = rows[-1]
            print("CSV Row Keys:", latest_entry.keys())

            features_values = []
            for feature in self.features:
                value_str = latest_entry.get(feature, "").strip()
                try:
                    value = float(value_str)
                except ValueError:
                    print(f"Warning: Could not convert value for {feature}: '{value_str}', using 0.0")
                    value = 0.0
                features_values.append(value)

            try:
                predicted_wqi = float(latest_entry.get("Predicted WQI", "0").strip())
            except ValueError:
                print("Warning: Could not convert Predicted WQI, using 0.0")
                predicted_wqi = 0.0

            self.last_data = features_values
            self.last_prediction = predicted_wqi
            self.last_update_time = time.strftime("%Y-%m-%d %H:%M:%S")

            # Update full dataframe cache
            self.cached_df = pd.DataFrame(rows)

            return features_values

        except Exception as e:
            print(f"Error getting latest row: {str(e)}")
            return None

    def update_data(self):
        print("Updating data from Google Sheets...")
        self.get_latest_row()

    def get_latest_data(self):
        return {
            "features": self.last_data,
            "prediction": self.last_prediction,
            "update_time": self.last_update_time,
            "feature_names": self.features
        }

    def load_full_dataframe(self):
        try:
            if self.cached_df is not None:
                df = self.cached_df.copy()
            else:
                response = requests.get(self.sheets_url)
                if response.status_code != 200:
                    raise Exception(f"Failed to fetch CSV: HTTP {response.status_code}")
                csv_data = response.content.decode("utf-8")
                df = pd.read_csv(StringIO(csv_data))

            df.columns = [col.strip() for col in df.columns]

            if "timestamp" not in df.columns or "Predicted WQI" not in df.columns:
                raise Exception("Required columns 'timestamp' and 'Predicted WQI' not found in sheet")

            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
            df["prediction"] = pd.to_numeric(df["Predicted WQI"], errors="coerce")

            df.dropna(subset=["timestamp", "prediction"], inplace=True)
            df.sort_values(by="timestamp", inplace=True)

            return df

        except Exception as e:
            print(f"Error loading full dataframe: {str(e)}")
            return pd.DataFrame(columns=["timestamp", "prediction"])

    def get_history_data(self, hours=None, start=None, end=None):
        """
        Returns WQI prediction history filtered by either:
        - last `hours` (int)
        - or start/end (string in YYYY-MM-DD format)
        """
        try:
            df = self.load_full_dataframe()

            if df.empty:
                return {"timestamps": [], "wqi_values": []}

            if hours:
                cutoff = datetime.now() - timedelta(hours=int(hours))
                df = df[df["timestamp"] >= cutoff]

            elif start and end:
                start_dt = datetime.strptime(start, "%Y-%m-%d")
                end_dt = datetime.strptime(end, "%Y-%m-%d") + timedelta(days=1)
                df = df[(df["timestamp"] >= start_dt) & (df["timestamp"] < end_dt)]

            return {
                "timestamps": df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S").tolist(),
                "wqi_values": df["prediction"].round(2).tolist()
            }

        except Exception as e:
            print(f"Error in get_history_data: {str(e)}")
            return {"timestamps": [], "wqi_values": []}

    def run_scheduler(self):
        while True:
            schedule.run_pending()
            time.sleep(1)

    def start_scheduler(self):
        schedule.every(5).seconds.do(self.update_data_once)
        schedule.every(1).minutes.do(self.update_data)
        thread = threading.Thread(target=self.run_scheduler)
        thread.daemon = True
        thread.start()

    def update_data_once(self):
        self.update_data()
        return schedule.CancelJob

# For testing
if __name__ == "__main__":
    connector = SheetsConnector("https://docs.google.com/spreadsheets/d/e/2PACX-1vQxvp6iMsxUCzFJRt4V7QQR2mkhEvIb2vAIDKG3GlC_a5PrNrU2IJ2gP2DHqOlz_095HlHDXpa1kAsK/pub?output=csv")
    df = connector.load_full_dataframe()
    print(df.head())
