# Configuration settings for the Water Quality Index Predictor

# Google Sheets Configuration
# Replace with your Google Sheets ID (from the URL)
SPREADSHEET_ID = "https://docs.google.com/spreadsheets/d/e/2PACX-1vQxvp6iMsxUCzFJRt4V7QQR2mkhEvIb2vAIDKG3GlC_a5PrNrU2IJ2gP2DHqOlz_095HlHDXpa1kAsK/pub?output=csv"

# Feature names in order (must match your model's expected input)
FEATURES = [
    "pH",
    "TDS",
    "Turbidity",
    "Temperature"
]

# Google Sheets column mapping for both JSON API and CSV format
# These mappings should handle both formats
COLUMN_MAPPING = {
    "ph": "pH",
    "tds": "TDS",
    "turbidity": "Turbidity",
    "temperature": "Temperature",
    "predictedwqi": "Predicted WQI"
}

# Update interval in minutes
UPDATE_INTERVAL = 15

# Flask app settings
PORT = 5000
HOST = "0.0.0.0"
DEBUG = True

# Gradient Boosting model file path (changed from XGBoost.json to .pkl)
MODEL_PATH = None