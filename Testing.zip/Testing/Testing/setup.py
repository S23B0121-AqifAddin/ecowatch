"""
Setup script to install required packages for the EcoWatch Dashboard
"""
import subprocess
import sys
import os

# Required packages (no ML needed)
requirements = [
    "flask",
    "pandas",
    "numpy",
    "requests",
    "schedule"
]

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info.major < 3 or (sys.version_info.major == 3 and sys.version_info.minor < 6):
        print("Error: This application requires Python 3.6 or higher")
        return False
    return True

def install_packages():
    """Install required packages using pip"""
    print("Installing required packages...")
    
    for package in requirements:
        print(f"Installing {package}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
            print(f"Successfully installed {package}")
        except subprocess.CalledProcessError:
            print(f"Error installing {package}. Please try to install it manually.")
            return False
    
    return True

def check_config_file():
    """Check if the config file exists and has been updated"""
    if not os.path.isfile("config.py"):
        print("Creating default config.py file...")
        with open("config.py", "w") as f:
            f.write(\"\"\"# Configuration settings for the EcoWatch Dashboard

SPREADSHEET_ID = "your-spreadsheet-id-here"

FEATURES = ["pH", "TDS", "Turbidity", "Temperature"]

COLUMN_MAPPING = {
    "ph": "pH",
    "tds": "TDS",
    "turbidity": "Turbidity",
    "temperature": "Temperature",
    "predictedwqi": "Predicted WQI"
}

UPDATE_INTERVAL = 1
PORT = 5000
HOST = "0.0.0.0"
DEBUG = True
MODEL_PATH = None  # Not used anymore
\"\"\")
        
        print("Default config.py created!")
        print("IMPORTANT: Please update the SPREADSHEET_ID in the config.py file")
        return False
        
    # Warn if config contains placeholder ID
    with open("config.py", "r") as f:
        content = f.read()
        if "your-spreadsheet-id-here" in content:
            print("Warning: Default spreadsheet ID detected in config.py.")
            return False
    
    return True

def main():
    """Main setup function"""
    print("Setting up EcoWatch Dashboard System...")
    print("========================================")
    
    if not check_python_version():
        return
    if not install_packages():
        print("Setup failed during package installation.")
        return
    check_config_file()
    
    print("\\nSetup completed!")
    print("\\nTo run the application:")
    print("1. Ensure your Google Sheet is published to the web")
    print("2. Update the SPREADSHEET_ID in config.py")
    print("3. Run 'python app.py' to start the dashboard")

if __name__ == "__main__":
    main()
