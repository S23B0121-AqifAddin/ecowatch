from flask import Flask, jsonify, render_template, request
import os
import config
from sheets_connector_public import SheetsConnector
import pandas as pd
from datetime import datetime, timedelta

app = Flask(__name__)

# Initialize the Google Sheets connector
sheets_connector = SheetsConnector(config.SPREADSHEET_ID)
sheets_connector.column_mapping = config.COLUMN_MAPPING
sheets_connector.features = config.FEATURES

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/latest-data")
def get_latest_data():
    """Returns the latest data for the UI to display"""
    latest_data = sheets_connector.get_latest_data()
    return jsonify(latest_data)

@app.route("/api/history")
def get_history_data():
    try:
        df = sheets_connector.load_full_dataframe()
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors='coerce')
        df.dropna(subset=["timestamp"], inplace=True)
        df.sort_values(by="timestamp", inplace=True)

        # Get query parameters
        hours = request.args.get("hours")
        start = request.args.get("start")
        end = request.args.get("end")
        selected_type = request.args.get("type", "prediction")

        # Check if column exists
        if selected_type not in df.columns:
            return jsonify({"error": f"Missing '{selected_type}' column in data"}), 400

        # Filter by time or date range
        if not hours and not (start and end):
            return jsonify({"error": "Missing query parameters"}), 400

        if hours:
            try:
                hours = int(hours)
                cutoff = datetime.now() - timedelta(hours=hours)
                df = df[df["timestamp"] >= cutoff]
            except ValueError:
                return jsonify({"error": "Invalid hours parameter"}), 400
        elif start and end:
            try:
                start_dt = pd.to_datetime(start)
                end_dt = pd.to_datetime(end) + pd.Timedelta(days=1)
                df = df[(df["timestamp"] >= start_dt) & (df["timestamp"] < end_dt)]
            except ValueError:
                return jsonify({"error": "Invalid start/end date"}), 400

        if df.empty:
            return jsonify({"timestamps": [], "values": []})

        timestamps = df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S").tolist()
        values = df[selected_type].astype(float).tolist()

        return jsonify({"timestamps": timestamps, "values": values})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/manual-update")
def manual_update():
    """Manually trigger an update from Google Sheets"""
    sheets_connector.update_data()
    return jsonify({"status": "success", "message": "Data update triggered"})

# Ensure templates folder exists
os.makedirs("templates", exist_ok=True)

# Create a basic index.html if not already provided
if not os.path.exists("templates/index.html"):
    with open("templates/index.html", "w") as f:
        f.write("""
        <!DOCTYPE html>
        <html lang="en">
        <head><meta charset="UTF-8"><title>EcoWatch</title></head>
        <body><h1>EcoWatch Dashboard is running.</h1></body>
        </html>
        """)

if __name__ == "__main__":
    app.run(debug=config.DEBUG, host=config.HOST, port=config.PORT)
